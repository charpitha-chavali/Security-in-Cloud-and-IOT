STEP - 1:
Visit the AWS Sign Up Page
STEP - 2:
Enter Contact Information
STEP - 3:
Verify Email
STEP - 4:
Create Root Password
STEP - 5:
Identity Confirmation
STEP - 6:
Choose Account Type
STEP - 7:
Provide Address & Phone Details
STEP - 8:
Payment Verification
STEP - 9:
Account Successfully Created
STEP - 10:
Complete Identity Verification (PAN)
STEP - 11:
Phone Number Verification
STEP - 12:
AWS Console Access
STEP - 13:
Billing & Account Management
STEP - 14:
AWS Login Options
  > Root User
  > IAM User
STEP - 15:
Turn On MFA
STEP - 16:
MFA Finished
CREATING THE MFA ENFORCEMENT POLICY
  > Step-1 : Open IAM policies
  > Step-2 : Create  a New Policy 
  > Step-3 : Specify Permissions Using JSON
  > Step-4 : Review and Name the Policy
  > Step-5 : Create the Policy 
  > Step-6 : Verify Policy Details
  > Step-7 : Policy Ready for Use 


